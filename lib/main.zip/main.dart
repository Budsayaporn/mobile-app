import 'package:flutter/material.dart';
import 'page2.dart';
import 'page03.dart';
import 'page4.dart';
import 'page05.dart';
import 'page6.dart';
import 'page07.dart';
import 'page8.dart';
import 'page09.dart';
import 'page10.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ร้านอาหาน้องถ่าน',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => MainMenu(),
        '/page2': (context) => Page2(title: "ข้าวผัด"),
        '/page03': (context) => Page03(title: "ต้มยำกุ้ง"),
        '/page4': (context) => Page4(title: "แกงฮังเล"),
        '/page05': (context) => Page05(title: "ส้มตำ"),
        '/page6': (context) => Page6(title: "ยำทะเล"),
        '/page07': (context) => Page07(title: "ขนมครก"),
        '/page8': (context) => Page8(title: "ติ่มซัม"),
        '/page09': (context) => Page09(title: "นักเก็ตไก่"),
        '/page10': (context) => Page10(title: "ขนมปังสังขยาโทสต์"),
      },
    );
  }
}

class MainMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('เมนูหลัก'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          MenuButton(title: "ข้าวผัด", route: '/page2'),
          MenuButton(title: "ต้มยำกุ้ง", route: '/page03'),
          MenuButton(title: "แกงฮังเล", route: '/page4'),
          MenuButton(title: "ส้มตำ", route: '/page05'),
          MenuButton(title: "ยำทะเล", route: '/page6'),
          MenuButton(title: "ขนมครก", route: '/page07'),
          MenuButton(title: "ติ่มซัม", route: '/page8'),
          MenuButton(title: "นักเก็ตไก่", route: '/page09'),
          MenuButton(title: "ขนมปังสังขยาโทสต์", route: '/page10'),
        ],
      ),
    );
  }
}

class MenuButton extends StatelessWidget {
  final String title;
  final String route;

  MenuButton({required this.title, required this.route});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: ElevatedButton(
        onPressed: () {
          Navigator.pushNamed(context, route);
        },
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.symmetric(vertical: 16.0),
          textStyle: TextStyle(fontSize: 18.0),
        ),
        child: Text(title),
      ),
    );
  }
}
