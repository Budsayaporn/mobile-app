import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page10 extends StatefulWidget {
  const Page10({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Page01State createState() => Page01State();
}

class Page01State extends State<Page10> {
   void _launchYouTube() async {
    const url = 'https://www.youtube.com/watch?v=ohWTk8dXdU4&pp=ygVC4Liq4Lit4LiZ4LiX4Liz4LiC4LiZ4Lih4Lib4Lix4LiH4Liq4Lix4LiH4LiC4Lii4Liy4LmC4LiX4Liq4LiV4LmM';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'ไม่สามารถเปิดลิงก์ได้: $url';
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          // รูปภาพพร้อมกรอบ
          Expanded(
            flex: 5,
            child: Container(
              margin: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                border:
                    Border.all(color: Colors.grey, width: 4), // กรอบสีเทารอบรูป
                borderRadius: BorderRadius.circular(12), // มุมโค้งมน
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8), // มุมโค้งมนให้รูปภาพ
                child: Image.network(
                  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBz2nkOvP00dT-5vw5jkrglkGD3k5BN5Ib7kBDVnK1v81izDHk5IFXfzCwRvhi5Z_7qQc&usqp=CAU',
                   width:  500,
                   height: 500,
                ),
              ),
            ),
          ),
          // ข้อมูลแสดงผล (จัดข้อความตรงกลาง)
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.center, // จัดให้อยู่ตรงกลางแนวนอน
                mainAxisAlignment:
                    MainAxisAlignment.center, // จัดให้อยู่ตรงกลางแนวตั้ง
                children: [
                  Text(
                    'ขนมปังสังขยาโทสต์',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center, // ข้อความจัดตรงกลาง
                  ),
                  SizedBox(height: 10),
                  Text(
                    ' ไข่ไก่ 2 ฟอง /นมสด 1 ถ้วย (หรือกะทิ) /น้ำตาลทราย 3/4 ถ้วย /น้ำใบเตยคั้นเข้มข้น 2 ช้อนชา /กลิ่นวานิลลา 1 ช้อนชา (ใส่หรือไม่ใส่ก็ได้) /นมข้นจืด 1/4 ถ้วย (และเตรียมไว้สำหรับราดด้านบนก่อนเสิร์ฟด้วย) /ท็อปปิ้ง ได้แก่ น้ำผึ้ง (สำหรับราด), ไอศกรีมวานิลลา, อัลมอนด์สไลซ์ (โรยหน้า), กล้วยหอมสไลซ์ และวิปปิ้งครีม (สำหรับแต่ง) ',
                    style: TextStyle(fontSize: 18),
                    textAlign: TextAlign.center, // ข้อความจัดตรงกลาง
                  ),
                  SizedBox(height: 20),
                  // ปุ่มลิงก์ไปที่ YouTube
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: _launchYouTube,
                      icon: Icon(Icons.video_library),
                      label: Text('ไปที่ YouTube'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
