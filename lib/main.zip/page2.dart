import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page2 extends StatefulWidget {
  const Page2({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Page2State createState() => Page2State();
}

class Page2State extends State<Page2> {
  // ฟังก์ชันเปิดลิงก์
  void _launchYouTube() async {
    const url = 'https://www.youtube.com/watch?v=tvZ0RXnOzWU';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'ไม่สามารถเปิดลิงก์ได้: $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          // รูปภาพแสดงผลแบบเต็มหน้าจอ (ครึ่งบน)
          Expanded(
            flex: 5,
            child: Image.network(
              'https://www.maggi.co.th/sites/default/files/styles/home_stage_944_531/public/srh_recipes/9f922d8fe6344f4a8b641ebd716be4cd.jpg?h=4f5b30f1&itok=KRUdjO7X',
               width:  500,
               height: 500,
            ),
          ),
          // ข้อมูลแสดงผล (ครึ่งล่าง)
          Expanded(
            flex: 4,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ข้าวผัด',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'ข้าวผัด เป็นอาหารจานเดียวแบบพื้นฐานของเอเชีย เป็นการนำข้าวสวยลงไปผัดคลุกกับซอส หรือน้ำพริก หรือเครื่องปรุงรสต่างๆ เพื่อให้ได้รสชาติ '
                    'ส่วนประกอบ ข้าวสวยหุงสุก 1 ถ้วย / ไข่ไก่ 2 ฟอง /ต้นหอม 1 ช้อนโต๊ะ /เกลือ ½ ช้อนชา /พริกไทย 1 ช้อนชา /น้ำมันพืช 3 ช้อนโต๊ะ',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 20),
                  // ปุ่มลิงก์ไปที่ YouTube
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: _launchYouTube,
                      icon: Icon(Icons.video_library),
                      label: Text('ไปที่ YouTube'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
