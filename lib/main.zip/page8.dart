import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page8 extends StatefulWidget {
  const Page8({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Page01State createState() => Page01State();
}

class Page01State extends State<Page8> {
   void _launchYouTube() async {
    const url = 'https://www.youtube.com/watch?v=1xXT6jle1UA&pp=ygUk4Liq4Lit4LiZ4LiX4Liz4LiV4Li04LmI4Lih4LiL4Lix4Lih';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'ไม่สามารถเปิดลิงก์ได้: $url';
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          // รูปภาพพร้อมกรอบ
          Expanded(
            flex: 5,
            child: Container(
              margin: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                border:
                    Border.all(color: Colors.grey, width: 4), // กรอบสีเทารอบรูป
                borderRadius: BorderRadius.circular(12), // มุมโค้งมน
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8), // มุมโค้งมนให้รูปภาพ
                child: Image.network(
                  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTJRSKIzsuEY76gnf7dRUUtT7744QwuleWhg&s',
                   width:  500,
                   height: 500,
                ),
              ),
            ),
          ),
          // ข้อมูลแสดงผล (จัดข้อความตรงกลาง)
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.center, // จัดให้อยู่ตรงกลางแนวนอน
                mainAxisAlignment:
                    MainAxisAlignment.center, // จัดให้อยู่ตรงกลางแนวตั้ง
                children: [
                  Text(
                    'ติ่มซัม',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center, // ข้อความจัดตรงกลาง
                  ),
                  SizedBox(height: 10),
                  Text(
                    'ติ่มซำ เป็นอาหารว่างหรืออาหารเรียกน้ำย่อยของจีน นิยมรับประทานกับน้ำชา ที่เป็นที่รู้จักกันทั่วโลก เป็นคำเรียกรวมอาหารหลายอย่าง มักเป็นอาหารจำพวกปรุงด้วยการนึ่ง เช่น ขนมจีบ, ซาลาเปา, ฮะเก๋า, เกี๊ยวซ่า เป็นต้น',
                    style: TextStyle(fontSize: 18),
                    textAlign: TextAlign.center, // ข้อความจัดตรงกลาง
                  ),
                  SizedBox(height: 20),
                  // ปุ่มลิงก์ไปที่ YouTube
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: _launchYouTube,
                      icon: Icon(Icons.video_library),
                      label: Text('ไปที่ YouTube'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
