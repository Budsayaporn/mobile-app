import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page03 extends StatefulWidget {
  const Page03({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Page01State createState() => Page01State();
}

class Page01State extends State<Page03> {
   void _launchYouTube() async {
    const url = 'https://www.youtube.com/watch?v=R4VXVwVS3Yk&pp=ygUq4Liq4Lit4LiZ4LiX4Liz4LiV4LmJ4Lih4Lii4Liz4LiB4Li44LmJ4LiH';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'ไม่สามารถเปิดลิงก์ได้: $url';
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          // รูปภาพแสดงผลแบบเต็มหน้าจอ (ครึ่งบน)
          Expanded(
            flex: 5,
            child: Image.network(
              'https://scontent-bkk1-2.xx.fbcdn.net/v/t1.6435-9/59879576_1060321497497461_7300709229352976384_n.jpg?stp=dst-jpg_p180x540&_nc_cat=103&ccb=1-7&_nc_sid=127cfc&_nc_eui2=AeHX8ntrKJ5-bdqVeGy9SCDrvBiT10URIxC8GJPXRREjEOYQHt2wshSaRNt663R2wkHfea213N-mpfTOoN7rElxY&_nc_ohc=K7FKTf0Yq0IQ7kNvgFsR1VK&_nc_zt=23&_nc_ht=scontent-bkk1-2.xx&_nc_gid=AmIOqFd2XWJmROPu_LOhO3M&oh=00_AYBa3jco1Ww8dAAoSKgPs5R6AWs_Ak9_B2fdtluBC0lswA&oe=675A2273',
              width:  500,
              height: 500,
            ),
          ),
          // ข้อมูลแสดงผล (ครึ่งล่าง)
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ต้มยำกุ้ง',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'ต้มยำกุ้ง เป็นอาหารไทยภาคกลางประเภทต้มยำ ซึ่งเป็นที่นิยมรับประทานไปทุกภาคในประเทศไทย เป็นอาหารที่รับประทานกับข้าว มีรสเปรี้ยวและเผ็ดเป็นหลักผสมเค็มและหวานเล็กน้อย ' 
                    'แบ่งออกเป็น 2 ประเภท คือ ต้มยำน้ำใส และ ต้มยำน้ำข้น'
                    'ส่วนประกอบ /ตะไคร้ 3 ต้น /ข่า 1 แข่ง /หอมแดง 3 ลูก /ใบมะกรูดฉีก /น้ำพริกเผา 2 ช้อนโต๊ะ /เห็ดฟาง /พริกขี้หนูสวน /พริกแดจินดา /น้ำปลา /กุ้งสด /ผักชีฝรั่ง',
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(height: 20),
                  // ปุ่มลิงก์ไปที่ YouTube
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: _launchYouTube,
                      icon: Icon(Icons.video_library),
                      label: Text('ไปที่ YouTube'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
