import 'package:flutter/material.dart';

class Page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> foodList = [
      {"name": "ข้าวผัด", "route": "/page2"},
      {"name": "ต้มยำกุ้ง", "route": "/page03"},
      {"name": "แกงฮังเล", "route": "/page4"},
      {"name": "ส้มตำ", "route": "/page05"},
      {"name": "ยำทะเล", "route": "/page6"},
      {"name": "ขนมครก", "route": "/page07"},
      {"name": "ติ่มซัม", "route": "/page8"},
      {"name": "นักเก็ตไก่", "route": "/page09"},
      {"name": "ขนมปังสังขยาโทสต์", "route": "/page10"},
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text("เมนูอาหาร"),
      ),
      body: ListView.builder(
        itemCount: foodList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(foodList[index]['name']!),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.pushNamed(context, foodList[index]['route']!);
            },
          );
        },
      ),
    );
  }
}
