import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page09 extends StatefulWidget {
  const Page09({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Page01State createState() => Page01State();
}

class Page01State extends State<Page09> {
   void _launchYouTube() async {
    const url = 'https://www.youtube.com/watch?v=N5oaIAIqU4w&pp=ygUw4Liq4Lit4LiZ4LiX4LiX4Liz4LiZ4Lix4LiB4LmA4LiB4LmH4LiV4LmE4LiB4LmI';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'ไม่สามารถเปิดลิงก์ได้: $url';
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          // รูปภาพพร้อมกรอบ
          Expanded(
            flex: 5,
            child: Container(
              margin: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                border:
                    Border.all(color: Colors.grey, width: 4), // กรอบสีเทารอบรูป
                borderRadius: BorderRadius.circular(12), // มุมโค้งมน
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8), // มุมโค้งมนให้รูปภาพ
                child: Image.network(
                  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbf8yvIX0D5r9jk80pLa8xQ85OJzCBNVS6iQ&s',
                   width:  500,
                   height: 500,
                ),
              ),
            ),
          ),
          // ข้อมูลแสดงผล (จัดข้อความตรงกลาง)
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.center, // จัดให้อยู่ตรงกลางแนวนอน
                mainAxisAlignment:
                    MainAxisAlignment.center, // จัดให้อยู่ตรงกลางแนวตั้ง
                children: [
                  Text(
                    'นักเก็ตไก่',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center, // ข้อความจัดตรงกลาง
                  ),
                  SizedBox(height: 10),
                  Text(
                    'นักเก็ตไก่เป็นผลิตภัณฑ์อาหารที่ประกอบด้วยเนื้อไก่เลาะกระดูกชิ้นเล็กๆ ที่ชุบเกล็ดขนมปังหรือชุบแป้ง แล้วนำไปทอดหรืออบ'
                    ' ส่วนประกอบ  /ไก่บด 500 กรัม /พริกไทยป่น 2 ช้อนโต๊ะ  /ซีอิ๊วขาว 2 ช้อนโต๊ะ /ซอสหอยนางรม 2 ช้อนโต๊ะ /เกลือ 2 ช้อนชา /แป้งข้าวโพด 4 ช้อนโต๊ะ  /แป้งสาลีอเนกประสงค์ 200 กรัม /ไข่ไก่ 2 ฟอง  /เกล็ดขนมปัง 200 กรัม /น้ำมันสำหรับทอด',
                    style: TextStyle(fontSize: 18),
                    textAlign: TextAlign.center, // ข้อความจัดตรงกลาง
                  ),
                  SizedBox(height: 20),
                  // ปุ่มลิงก์ไปที่ YouTube
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: _launchYouTube,
                      icon: Icon(Icons.video_library),
                      label: Text('ไปที่ YouTube'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
